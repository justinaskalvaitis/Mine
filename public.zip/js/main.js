$(document).ready(function(){
	$('header').hover(function(){
		$('#vertical_text').stop().slideToggle('slow');
		$('#vertical_text2').stop().slideDown('slow');
	});
});

$(document).ready(function(){
	$('.container').hover(function(){
		$('#text').stop().slideDown('slow');
	});
});

$(document).ready(function(){
	$('.mainbackground').hover(function(){
		$('#text2').stop().slideDown('slow');
	});
}); 
$(document).ready(function(){
	$('.xx1').hover(function(){
		$('#vertical_text3').fadeToggle("slow");
		$('#vertical_text4').fadeToggle("slow");
	});
});

$(document).ready(function(){
	$('.xx2').hover(function(){
		$('#vertical_text5').fadeToggle("slow");
		$('#vertical_text6').fadeToggle("slow");
	});
});

$(document).ready(function(){
	$('.xx3').hover(function(){
		$('#vertical_text7').fadeToggle("slow");
		$('#vertical_text8').fadeToggle("slow");
	});
});

