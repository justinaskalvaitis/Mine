<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-offset-3 thumbnail">
			<h3><strong><?php echo e($products->title); ?></strong></h3>

			<img src="<?php echo e($products->photo); ?>" class="img-responsive" width="500" >
			<p><strong><?php echo e($products->description); ?></strong></p>
			<ul>
				<li><strong>Price: <?php echo e($products->price); ?> eur</strong></li>
				<li><strong>Quantity: <?php echo e($products->quantity); ?> eur</strong></li>
			</ul>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tech', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>