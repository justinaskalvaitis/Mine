<?php $__env->startSection('content'); ?>
<div class="container">
<h2>Užsakymai</h2>
	<?php $__currentLoopData = $orders->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="row">
		<?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-4">
				<div class="thumbnail">
					<a href ="<?php echo e(route('orders.show', $order->id)); ?>"><p><?php echo e($order->name); ?></p></a>
 						
 						<p><?php echo e($order->phone); ?></p>
 						<p><?php echo e($order->created_at); ?></p>
 						<?php if(Auth::user() && Auth::user()->isAdmin()): ?>
							<a href="<?php echo e(route('orders.edit', $order->id)); ?>" class="btn btn-success">Keisti</a>
						<?php endif; ?>
						
 					</div>
 				</div>
 		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>