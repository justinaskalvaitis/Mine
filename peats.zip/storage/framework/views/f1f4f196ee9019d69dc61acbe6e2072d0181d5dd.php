<?php $__env->startSection('content'); ?>
<div class="container">

	<?php if(isset($aboutus)): ?>
		<h2>Užsakymo taisymas - <?php echo e($aboutus->name); ?></h2>
		<?php echo Form::model($aboutus, ['route' => ['aboutus.update', $aboutus->id], 'method' => 'put']); ?>

	<?php else: ?>
		<?php echo Form::open(['route' => ['aboutus.store'], 'method' => 'POST']); ?>

	<?php endif; ?>

	<div class="form-group">
		<h4>Antraštė</h4>
		<?php echo Form::text('title', null); ?>

	</div>

	<div class="form-group">
		<h4>Komentaras</h4>
		<?php echo Form::textarea('description', null); ?>

	</div>





	<?php echo Form::submit('save', ['class' => 'btn btn-primary']); ?>

		<?php echo Form::close(); ?>


		
		<?php if(isset($aboutuses)): ?>


			<?php echo Form::open(['route'=> ['aboutuses.destroy', $aboutuses->id], 'method' => 'DELETE']); ?>

			<?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>




		<?php echo Form::close(); ?>

		<?php endif; ?>
</div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>