<?php $__env->startSection('content'); ?>

<div class="container">

	<?php if(isset($contacts)): ?>
		<h2>Kontaktų taisymas - <?php echo e($contacts->name); ?></h2>
		<?php echo Form::model($contacts, ['route' => ['contacts.update', $contacts->id], 'method' => 'put']); ?>

	<?php else: ?>
		<?php echo Form::open(['route' => ['contacts.store'], 'method' => 'POST']); ?>

	<?php endif; ?>

	<div class="form-group">
		<h4>Antraštė</h4>
		<?php echo Form::text('title', null, ['class' => 'form-control', 'placeholder' => 'title']); ?>

	</div>

	<div class="form-group">
		<h4>Adresas</h4>
		<?php echo Form::text('address', null, ['class' => 'form-control', 'placeholder' => 'address']); ?>

	</div>

	<div class="form-group">
		<h4>Elektroninis paštas</h4>
		<?php echo Form::text('email', null, ['class' => 'form-control', 'placeholder' => 'email']); ?>

	</div>

	<div class="form-group">
		<h4>Telefonas</h4>
		<?php echo Form::text('phone', null, ['class' => 'form-control', 'placeholder' => 'phone']); ?>

	</div>

	<div class="form-group">
		<h4>Darbo valandos</h4>
		<?php echo Form::textarea('hours', null, ['class' => 'form-control', 'placeholder' => 'hours']); ?>

	</div>

	<div class="form-group">
		<h4>Žemėlapis</h4>
		<?php echo Form::textarea('map', null, ['class' => 'form-control', 'placeholder' => 'map']); ?>

	</div>

	<?php echo Form::submit('Saugoti', ['class' => 'btn btn-primary']); ?>





	<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>