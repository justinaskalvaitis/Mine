<?php $__env->startSection('content'); ?>
<div class="container">

	<?php if(isset($abouts)): ?>
		<h2>Užsakymo taisymas - <?php echo e($abouts->name); ?></h2>
		<?php echo Form::model($abouts, ['route' => ['about.update', $abouts->id], 'method' => 'put']); ?>

	<?php else: ?>
		<?php echo Form::open(['route' => ['about.store'], 'method' => 'POST']); ?>

	<?php endif; ?>

	<div class="form-group">
		<h4>Antraštė</h4>
		<?php echo Form::text('title', null); ?>

	</div>

	<div class="form-group">
		<h4>Komentaras</h4>
		<?php echo Form::textarea('comment', null); ?>

	</div>





	<?php echo Form::submit('Saugoti', ['class' => 'btn btn-primary']); ?>

		<?php echo Form::close(); ?>


		
		<?php if(isset($abouts)): ?>


			<?php echo Form::open(['route'=> ['about.destroy', $abouts->id], 'method' => 'DELETE']); ?>

			<?php echo Form::submit('Ištrinti', ['class' => 'btn btn-danger']); ?>




		<?php echo Form::close(); ?>

		<?php endif; ?>
</div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>