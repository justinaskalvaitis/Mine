 
 
 <?php $__env->startSection('content'); ?>
<div class="container">
 
		<?php if(isset($products)): ?>
		<h2>Produkto - <?php echo e($products->title); ?> - tvarkymas</h2>
		<?php echo Form::model($products, ['route' => ['products.update', $products->id], 'method' => 'put']); ?>

		<?php else: ?>
		<?php echo Form::open(['route' => ['products.store'], 'method' => 'POST']); ?>

		<?php endif; ?>
	
 
	<div class="form-group">
	<h4>Antraštė</h4>
	<?php echo Form::text('title', null); ?>

	</div>
 
	<div class="form-group">
	<h4>Aprašymas</h4>
	<?php echo Form::textarea('description', null); ?>

	</div>
 
	<div class="form-group">
	<h4>Kaina</h4>
	<?php echo Form::text('price', null); ?>

	</div>

	<div class="form-group">
	<h4>Tipas(kategorija)</h4>
	<?php echo Form::text('type', null); ?>

	</div>
	
	<div class="form-group">
	<h4>Nuotrauka</h4>
	<?php echo Form::text('photo', null, ['class' => 'form-control']); ?>

	</div>
	



	<?php echo Form::submit('Saugoti', ['class' => 'btn btn-primary']); ?>

	<?php echo Form::close(); ?>


	<?php if(Auth::user() && Auth::user()->isAdmin()): ?>
		<?php if(isset($products)): ?>

		
		<?php echo Form::open(['route'=> ['products.destroy', $products->id], 'method' => 'DELETE']); ?>

		<?php echo Form::submit('Trinti', ['class' => 'btn btn-danger']); ?>

		<?php endif; ?>



		<?php echo Form::close(); ?>

	<?php endif; ?>
</div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>