<?php $__env->startSection('content'); ?>
<div class="container">
		<?php $__currentLoopData = $abouts->chunk(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="row">
		<?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-12">
				<div class="thumbnail aboutUs">
 						<h3><strong><?php echo e($about->title); ?></strong></h3>
 						<p><strong><?php echo e($about->comment); ?></strong></p>
 						<?php if(Auth::user() && Auth::user()->isAdmin()): ?>
						<a href="<?php echo e(route('about.edit', $about->id)); ?>" class="btn btn-success">Keisti</a>
						<?php endif; ?>
 					</div>
 				</div>
 		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.juice', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>