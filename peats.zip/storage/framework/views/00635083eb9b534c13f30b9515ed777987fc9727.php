<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-10  thumbnail">
			<h2><?php echo e($order->name); ?></h2>
			<ul>
				<li>Elektorninis paštas: <?php echo e($order->email); ?> </li>	
				<li>Adresas: <?php echo e($order->address); ?> eur</li>			
				<li>Telefonas: <?php echo e($order->phone); ?></li>
				<li>Klausimai: <?php echo e($order->comment); ?></li>

			</ul>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>