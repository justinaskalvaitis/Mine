<?php $__env->startSection('content'); ?>
<div class="container">
	

<h2><strong>Išpilstymo taros</strong></h2>
	<?php $__currentLoopData = $products->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="row">

		<?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-4">
				<div class="thumbnail">

					<a href ="<?php echo e(route('juice.show', $product->id)); ?>"><img src="<?php echo e($product->photo); ?>"></a>
					<p><strong><?php echo e($product->title); ?></strong></p>
 						<p><strong><?php echo e($product->description); ?></strong></p>
						<p><strong>Kaina: <?php echo e($product->price); ?> Eur </strong></p>
						<?php if(Auth::user() && Auth::user()->isAdmin()): ?>
							<a href="<?php echo e(route('juice.edit', $product->id)); ?>" class="btn btn-success">Keisti</a>
						<?php endif; ?>
 					</div>
 				</div>
 		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.juice', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>