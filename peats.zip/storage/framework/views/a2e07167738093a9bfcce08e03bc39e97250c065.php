<?php $__env->startSection('content'); ?>
<div class="container">
	<?php if(isset($orders)): ?>
		<h2>Užsakymo taisymas - <?php echo e($orders->name); ?></h2>
		<?php echo Form::model($orders, ['route' => ['orders.update', $orders->id], 'method' => 'put']); ?>

	<?php else: ?>
		<?php echo Form::open(['route' => ['orders.store'], 'method' => 'POST']); ?>

		<h2 class="thumbnail">Klauskite kas domina, su jumis susisieksime kelių valandų bėgyje.</h2>
	<?php endif; ?>

	<div class="form-group">
		<h4>Vardas</h4>
		<?php echo Form::text('name', null); ?>

	</div>

	<div class="form-group">
		<h4>Namų adresas</h4>
		<?php echo Form::text('address', null); ?>

	</div>

	<div class="form-group">
		<h4>Elektroninis paštas</h4>
		<?php echo Form::text('email', null); ?>

	</div>

	<div class="form-group">
		<h4>Phone</h4>
		<?php echo Form::text('phone', null); ?>

	</div>

	<div class="form-group">
		<h4>Komentaras</h4>
		<?php echo Form::textarea('comment', null); ?>

	</div>

	

	<?php echo Form::submit('Išsaugoti', ['class' => 'btn connectbtn']); ?>

	<?php echo Form::close(); ?>


	<?php if(Auth::user() && Auth::user()->isAdmin()): ?>
		<?php if(isset($orders)): ?>


		<?php echo Form::open(['route'=> ['orders.destroy', $orders->id], 'method' => 'DELETE']); ?>

		<?php echo Form::submit('Ištrinti', ['class' => 'btn connectbtn']); ?>




		<?php echo Form::close(); ?>

		<?php endif; ?>
	<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tech', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>