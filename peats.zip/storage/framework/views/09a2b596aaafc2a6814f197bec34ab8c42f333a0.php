<?php $__env->startSection('content'); ?>
<div class="container contact">
	<div class="row">
		<div class="col-md-5 contactstwo">
			<h2><strong>Kontaktai</strong></h2>		
				<p><strong><?php echo e($contacts['title']); ?></strong></p>
				<p><strong>Adresas: <?php echo e($contacts['address']); ?></strong></p>
				<p><strong>El. paštas: <?php echo e($contacts['email']); ?></strong></p>
				<p><strong>Telefonas: <?php echo e($contacts['phone']); ?></strong></p>		
		</div>
		<div class="col-md-7 contact">
			<strong><?php echo $contacts->hours; ?></strong>
			<?php if(Auth::user() && Auth::user()->isAdmin()): ?>
				<a href="<?php echo e(route('contacts.edit', $contacts->id)); ?>" class="btn btn-success">Keisti</a>
			<?php endif; ?>
		</div>
		
	</div>
</div>
<div >
	<?php echo $contacts['map']; ?>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>