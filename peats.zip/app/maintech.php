<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class maintech extends Model
{
    //
}
